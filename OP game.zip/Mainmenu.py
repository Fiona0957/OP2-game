def mainMenu():
    import pygame

    pygame.init()

    White = (255,255,255)
    Black = (0,0,0)
    Beige = (234,234,234)
    Window_height = 600
    Window_width = 800
    Window = pygame.display.set_mode((Window_width, Window_height))
    pygame.display.set_caption("To the Rescue")
    Window.fill(White)
    achtergrond_main = pygame.image.load('Achtergrond_main.png')
    achtergrond_main = pygame.transform.scale(achtergrond_main, (Window_width, Window_height+15))
    achtergrond_quit = pygame.image.load('Achtergrond_quit.png')
    achtergrond_quit = pygame.transform.scale(achtergrond_quit, (Window_width, Window_height+15))



    font = pygame.font.SysFont(None,25)

    def message_to_screen(msg, color):
        screen_text = font.render(msg,True,color)
        Window.blit(screen_text, [200, 200])

    desx = 0
    desy = 0
    def message_to_button(msg, color, desx, desy):

        screen_text = font.render(msg,True, color)
        Window.blit(screen_text, (desx, desy))

    def intro():
        intro = True
        while intro:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    quit()
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        exit()
            Window.blit(achtergrond_main, (0, 0))
            pygame.display.set_caption("To the Rescue")
            button(12, 18, 58, 56, 1, Beige, Beige, 1)
            button(455, 146, 298, 67, 1, Black, Black, 2)
            button(455, 223, 298, 67, 1, Black, Black, 3)
            button(454, 298, 299, 68, 1, Black, Black, 4)
            button(454, 378, 299, 67, 1, Black, Black, 5)
            button(454, 456, 299, 66, 1, Black, Black, 6)
            message_to_button("911, what's your emergency?", Black, 485, 70)
            message_to_button("What do you need?", Black, 530, 110)
            message_to_button("Police", Black, 590, 170)
            message_to_button("Firefighter", Black, 590, 250)
            message_to_button("Ambulance", Black, 590, 325)
            message_to_button("Traffic controller", Black, 590, 405)
            message_to_button("Lifeguard", Black, 590, 480)
            pygame.display.update()

    def exit():
            exit = True
            while exit:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        quit()
                Window.blit(achtergrond_quit, (0, 0))
                message_to_button("Are you sure you want to quit?", Black, 480, 200)
                message_to_button("No", Black, 505, 370)
                message_to_button("Yes", Black, 675, 370)
                button(455, 257, 122, 110, 1 ,White, White, 9)
                button(625, 257, 122, 110, 1, White, White, 8)
                pygame.display.update()


    def game1():
        game1 = True
        while game1:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    quit()
            Window.fill(White)
            pygame.display.set_caption("To the Rescue - Game 1")
            message_to_screen("Game 1", Black)
            button(400, 200, 55, 55, 1, Black, Black, 10)
            message_to_button("Menu", Black, 405, 220)
            pygame.display.update()

    def game2():
        game2 = True
        while game2:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    quit()
            Window.fill(White)
            pygame.display.set_caption("To the Rescue - Game 2")
            message_to_screen("Game 2", Black)
            button(400, 200, 55, 55, 1, Black, Black, 10)
            message_to_button("Menu", Black, 405, 220)
            pygame.display.update()


    def game3():
        game3 = True
        while game3:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    quit()
            Window.fill(White)
            pygame.display.set_caption("To the Rescue - Game 3")
            message_to_screen("Game 3", Black)
            button(400, 200, 55, 55, 1, Black, Black, 10)
            message_to_button("Menu", Black, 405, 220)
            pygame.display.update()

    def game4():
        game4 = True
        while game4:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    quit()
            Window.fill(White)
            pygame.display.set_caption("To the Rescue - Game 4")
            message_to_screen("Game 4", Black)
            button(400, 200, 55, 55, 1, Black, Black, 10)
            message_to_button("Menu", Black, 405, 220)
            pygame.display.update()

    def game5():
        game5 = True
        while game5:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    quit()
            Window.fill(White)
            pygame.display.set_caption("To the Rescue - Game 5")
            message_to_screen("Game 5", Black)
            button(400, 200, 55, 55, 1, Black, Black, 10)
            message_to_button("Menu", Black, 405, 220)
            pygame.display.update()

    def button(x, y, width, height, line, inactive_color, active_color, number):
        cur = pygame.mouse.get_pos()
        if x+width>cur[0]>x and y+height>cur[1]>y:
            pygame.draw.rect(Window, active_color, (x,y,width,height), line+1)
            for event in pygame.event.get():
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if number == 1:
                        exit()
                    if number == 2:
                       politie.Highwaylaw()
                    if number == 3:
                       brandweer.game_loop()
                    if number == 4:
                       ambulance.minigametext()
                    if number == 5:
                       verkeersbrigade.Everything()
                    if number == 6:
                       lifeguard.lifeguardloop()
                    if number == 7:
                        intro()
                    if number == 8:
                        pygame.quit()
                        quit()
                    if number == 9:
                        intro()
                    if number == 10:
                        intro()
        else:
            pygame.draw.rect(Window, inactive_color, (x, y, width, height), line)



    gameExit = False

    while not gameExit:
        if gameExit == False:
            intro()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                gameExit = True

    pygame.quit()
mainMenu()
quit()